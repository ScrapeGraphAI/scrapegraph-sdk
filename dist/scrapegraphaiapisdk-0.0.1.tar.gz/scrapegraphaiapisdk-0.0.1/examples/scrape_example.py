from scrapegraphaiapisdk.scrape import scrape
from dotenv import load_dotenv  # Import load_dotenv
import os  # Import os to access environment variables
import json  # Import json for beautifying output

def main():
    """Main function to execute the scraping process."""
    load_dotenv()  # Load environment variables from .env file
    api_key = os.getenv("SCRAPEGRAPH_API_KEY")  # Get API key from environment variable
    url = "https://scrapegraphai.com/"  # The URL of the webpage to scrape
    prompt = "What does the company do?"  # Natural language prompt

    result = scrape(api_key, url, prompt)
    print(result)
if __name__ == "__main__":
    main()
