
def status(api_key: str) -> str:
    pass
